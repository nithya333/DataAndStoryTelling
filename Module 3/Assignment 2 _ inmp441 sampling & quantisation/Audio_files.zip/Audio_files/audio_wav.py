import serial
import struct
import numpy as np
import wave
import time
import matplotlib.pyplot as plt

# --- CONFIGURATION (MUST MATCH ARDUINO) ---
PORT = "COM6"          # Change to your ESP32 Port
BAUD = 921600
SAMPLING_RATE = 8000   # Set to 16000, 8000, or 4000
BIT_DEPTH = 16       # Set to 16, 8, or 4
DURATION_SEC = 2        # Recording duration

# Calculated Constants
OUTPUT_WAV = f"rec_{SAMPLING_RATE}Hz_{BIT_DEPTH}bit.wav"
TOTAL_SAMPLES = SAMPLING_RATE * DURATION_SEC

print(f"--- STARTING RECORDING: {SAMPLING_RATE}Hz / {BIT_DEPTH}-bit ---")
ser = serial.Serial(PORT, BAUD, timeout=1)
time.sleep(2)
ser.reset_input_buffer()

collected_samples = []

print("Listening...")
start_time = time.time()

while len(collected_samples) < TOTAL_SAMPLES:
    # 1. Sync with Header (0xAA 0x55)
    header = ser.read(2)
    if len(header) < 2 or header != b'\xAA\x55':
        continue

    # 2. Determine Frame Size based on buffer logic
    # ESP32 sends chunks. We read whatever is available or fixed size
    # For simplicity, we read small chunks corresponding to the loop
    # Ideally, read based on expected frame size from Arduino
    
    # Just read a chunk of bytes to process
    raw_data = ser.read(1024) 
    if not raw_data: continue

    # 3. Decode Data
    if BIT_DEPTH == 16:
        # Each sample is 2 bytes (int16)
        count = len(raw_data) // 2
        new_samples = struct.unpack(f'<{count}h', raw_data[:count*2])
        collected_samples.extend(new_samples)
        
    elif BIT_DEPTH == 8:
        # Each sample is 1 byte (int8)
        # Scale back up to 16-bit range for WAV saving
        for b in raw_data:
            val8 = struct.unpack('b', bytes([b]))[0] # signed char
            collected_samples.append(val8 * 256) 
            
    elif BIT_DEPTH == 4:
        # Each byte contains TWO 4-bit samples
        # Unpack nibbles and scale to 16-bit range
        for b in raw_data:
            # Upper nibble
            n1 = (b >> 4) & 0x0F
            # Lower nibble
            n2 = b & 0x0F
            
            # Map 0..15 -> -32768..32767
            # Formula: (val - 8) * 4096
            collected_samples.append((n1 - 8) * 4096)
            collected_samples.append((n2 - 8) * 4096)

    if time.time() - start_time > DURATION_SEC + 2:
        break

ser.close()
print(f"Captured {len(collected_samples)} samples.")

# Truncate to target
audio_data = np.array(collected_samples[:TOTAL_SAMPLES], dtype=np.int16)

# --- VISUALIZATION (Plot requested in notes) ---
plt.figure(figsize=(10, 4))
plt.plot(audio_data, color='blue', linewidth=0.5)
plt.title(f"Waveform: {SAMPLING_RATE}Hz / {BIT_DEPTH}-bit")
plt.xlabel("Sample Index")
plt.ylabel("Amplitude")
plt.ylim(-33000, 33000)
plt.grid(True)
plt.show()

# --- SAVE WAV ---
with wave.open(OUTPUT_WAV, "wb") as wf:
    wf.setnchannels(1)
    wf.setsampwidth(2)           # Always save as 16-bit container for compatibility
    wf.setframerate(SAMPLING_RATE)
    wf.writeframes(audio_data.tobytes())

print(f"Saved: {OUTPUT_WAV}")